MiniCluster 1.7.1 — Windows x64
==========================================

Binaries:
  minicluster-api.exe   — API server (web UI embedded)
  mc.exe                — CLI client

Quick start (no install):
  .\minicluster-api.exe

  The server reads config.yaml from the same directory.
  Open http://localhost:2016 in your browser.

  Use the CLI:
  .\mc.exe --help

Install as a Windows Service (requires Administrator):
  Right-click PowerShell → "Run as Administrator"
  cd <this directory>
  .\install.ps1

  This will:
  - Copy minicluster-api.exe and mc.exe to %ProgramFiles%\MiniCluster
  - Register the API as a Windows Service (auto-start)
  - Create data directory at %ProgramData%\MiniCluster
  - Add the install directory to the system PATH (mc available everywhere)

  To uninstall:
  .\install.ps1 -Uninstall

Environment variable overrides (prefix MINICLUSTER_):
  $env:MINICLUSTER_PORT = "8080"; .\minicluster-api.exe
  $env:MINICLUSTER_DATA_DIR = "C:\mc-data"; .\minicluster-api.exe

Default URL: http://localhost:2016
