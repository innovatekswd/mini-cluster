MiniCluster 1.7.1 — Linux amd64
==========================================

Binaries:
  minicluster-api   — API server (web UI embedded)
  mc                — CLI client

Quick start:
  chmod +x ./minicluster-api ./mc
  ./minicluster-api                    # listens on :2016
  ./mc --help

With custom config:
  cp config.yaml.example config.yaml  # edit as needed
  ./minicluster-api                    # reads ./config.yaml automatically

Environment overrides (prefix MINICLUSTER_):
  MINICLUSTER_PORT=8080 ./minicluster-api
  MINICLUSTER_DATA_DIR=/srv/mc ./minicluster-api

Systemd installation (manual):
  sudo cp minicluster-api /usr/bin/minicluster-api
  sudo cp mc /usr/bin/mc
  sudo cp minicluster.service /lib/systemd/system/
  sudo useradd --system --no-create-home minicluster
  sudo mkdir -p /var/lib/minicluster /etc/minicluster
  sudo chown -R minicluster:minicluster /var/lib/minicluster /etc/minicluster
  sudo cp config.yaml.example /etc/minicluster/config.yaml
  sudo systemctl daemon-reload
  sudo systemctl enable --now minicluster

Default URL: http://localhost:2016
